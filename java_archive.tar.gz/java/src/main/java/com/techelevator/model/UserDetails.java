package com.techelevator.model;

public class UserDetails {
}
