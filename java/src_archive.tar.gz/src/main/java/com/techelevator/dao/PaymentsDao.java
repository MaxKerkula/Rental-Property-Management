package com.techelevator.dao;

public interface PaymentsDao {
}
