package com.techelevator.service;

import com.techelevator.dao.MaintenanceDao;
import com.techelevator.exception.EntityNotFoundException;
import com.techelevator.model.Maintenance;
import com.techelevator.model.Property;
import com.techelevator.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.util.List;

@Service
public class MaintenanceServiceImp implements MaintenanceService {

    private MaintenanceDao maintenanceDao;
    private UserService userService;

    @Autowired
    public MaintenanceServiceImp(MaintenanceDao maintenanceDao, UserService userService) {
        this.maintenanceDao = maintenanceDao;
        this.userService = userService;
    }

    @Override
    public List<Maintenance> getAllRequests() {
        return maintenanceDao.getAllRequests();
    }

    @Override
    public Maintenance getRequestById(int requestId, Principal principal) {
        Maintenance request = maintenanceDao.getRequestById(requestId);
        if (request == null) {
            throw new EntityNotFoundException("Maintenance request not found.");
        }

        User currentUser = userService.findByUsername(principal.getName());
        if (!currentUser.getRole().equals("maintenance worker") && request.getMaintenanceWorkerId() != currentUser.getId() && request.getPropertyId() != currentUser.getProperty().getId()) {
            throw new AccessDeniedException("Access denied.");
        }

        return request;
    }

    @Override
    public int createRequest(Maintenance request, Principal principal) {
        User currentUser = userService.findByUsername(principal.getName());
        request.setPropertyId(currentUser.getProperty().getId());
        request.setCreatedBy(currentUser.getUsername());
        return maintenanceDao.createRequest(request);
    }

    @Override
    public boolean assignRequest(int requestId, int assignedTo, Principal principal) {
        Maintenance request = maintenanceDao.getRequestById(requestId);
        if (request == null) {
            throw new EntityNotFoundException("Maintenance request not found.");
        }

        User currentUser = userService.findByUsername(principal.getName());
        if (!currentUser.getRole().equals("landlord") && !request.getCreatedBy().equals(currentUser.getUsername())) {
            throw new AccessDeniedException("Access denied.");
        }

        return maintenanceDao.assignRequest(requestId, assignedTo);
    }

    @Override
    public boolean updateRequestStatus(int requestId, int statusId, Principal principal) {
        Maintenance request = maintenanceDao.getRequestById(requestId);
        if (request == null) {
            throw new EntityNotFoundException("Maintenance request not found.");
        }

        User currentUser = userService.findByUsername(principal.getName());
        if (!currentUser.getRole().equals("maintenance worker") && request.getMaintenanceWorkerId() != currentUser.getId() && request.getPropertyId() != currentUser.getProperty().getId()) {
            throw new AccessDeniedException("Access denied.");
        }

        return maintenanceDao.updateRequestStatus(requestId, statusId);
    }

    @Override
    public boolean deleteRequest(int requestId, Principal principal) {
        Maintenance request = maintenanceDao.getRequestById(requestId);
        if (request == null) {
            throw new EntityNotFoundException("Maintenance request not found.");
        }

        User currentUser = userService.findByUsername(principal.getName());
        if (!currentUser.getRole().equals("landlord") && !request.getCreatedBy().equals(currentUser.getUsername())) {
            throw new AccessDeniedException("Access denied.");
        }

        maintenanceDao.deleteRequest(requestId);
        return true;
    }
}
